package com.gijutsusol.indiaghumo;

import static com.gijutsusol.indiaghumo.GlobalVariable.message;
import static com.gijutsusol.indiaghumo.GlobalVariable.message1;
import static com.gijutsusol.indiaghumo.GlobalVariable.message2;
import static com.gijutsusol.indiaghumo.GlobalVariable.subject;

import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.gijutsusol.indiaghumo.databinding.ActivityMainBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONException;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private final ArrayList<String> cityList = new ArrayList<>();
    private AlertDialog alertDialog;
    private String city;
    private String poa1;
    private String poa2;
    private String pd1;
    private String pd2;
    private final String dbUrl = "https://indiaghumo-4dfda-default-rtdb.asia-southeast1.firebasedatabase.app/";
    private FirebaseUser mAuth;
    TextView txtView6;
    String location;
    Location closestLocation;
    int smallestDistance = -1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        txtView6 = findViewById(R.id.textView6);
        txtView6.setText(message2);

        mAuth = FirebaseAuth.getInstance().getCurrentUser();

        getAllCityName();

        loadDataForFirstTime();

        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, cityList);
        binding.etSearchBox.setAdapter(cityAdapter);

        if (mAuth == null) {
            binding.tvWhatsUp.setText("Welcome ");
            binding.tvUserName.setText("Guest");

        } else {
            getUserNameFromDB();
        }

        binding.etSearchBox.setOnItemClickListener((parent, view, position, id) -> {
            showProgressDialog();
            binding.scrollView.setVisibility(View.VISIBLE);
            binding.etSearchBox.setText("");
            getCityDetails(cityAdapter.getItem(position));
            city = cityAdapter.getItem(position);

            getCityDetailsFromWiki(city);
            TextView poa1t = findViewById(R.id.textpoa1);
            TextView poa2t = findViewById(R.id.textpoa2);
            poa1t.setText(poa1);
            poa2t.setText(poa2);
        });

        binding.ivPoa1.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", city);
            intent.putExtra("POA_NAME", poa1);

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });

        binding.ivPoa2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", city);
            intent.putExtra("POA_NAME", poa2);

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa2, 100, 100, 100, 100).toBundle());
        });

        binding.ivPda1.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PdestinationActivity.class);
            intent.putExtra("CITY_NAME", city);
            intent.putExtra("POA_NAME", poa1);

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });

        binding.ivPda2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PdestinationActivity.class);
            intent.putExtra("CITY_NAME", city);
            intent.putExtra("POA_NAME", poa2);

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa2, 100, 100, 100, 100).toBundle());
        });

        binding.cvCity.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CityActivity.class);
            intent.putExtra("CITY_NAME", city);
            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });

        binding.cityArea.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CityActivity.class);
            intent.putExtra("CITY_NAME", city);
            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa2, 100, 100, 100, 100).toBundle());
        });
        TextView loc = findViewById(R.id.textView6);
        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,LocationActivity.class);
                startActivity(i);
            }
        });
        ImageView navBtn = findViewById(R.id.cab_menu);

        navBtn.setOnClickListener(v -> {
            binding.drawerLayout.openDrawer(GravityCompat.START);
        });
        binding.cvPoa.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this,PoaListActivity.class);
            intent.putExtra("CITY_NAME",city);
            startActivity(intent,ActivityOptions.makeScaleUpAnimation(binding.ivPoa1,100,100,100,100).toBundle());
        });
        binding.cvPda.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this,PdListActivity.class);
            intent.putExtra("CITY_NAME",city);
            startActivity(intent,ActivityOptions.makeScaleUpAnimation(binding.ivPda1,100,100,100,100).toBundle());
        });
        binding.cvRp.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this,RpListActivity.class);
            intent.putExtra("CITY_NAME",city);
            startActivity(intent,ActivityOptions.makeScaleUpAnimation(binding.ivPda1,100,100,100,100).toBundle());
        });
        binding.cvChd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this,ChdListActivity.class);
            intent.putExtra("CITY_NAME",city);
            startActivity(intent,ActivityOptions.makeScaleUpAnimation(binding.ivPda1,100,100,100,100).toBundle());
        });



        Menu nav_Menu = binding.navigationView.getMenu();
        if (FirebaseAuth.getInstance().getCurrentUser()==null) {
            nav_Menu.findItem(R.id.logout).setVisible(false);
        }else{
            nav_Menu.findItem(R.id.sign456).setVisible(false);
            nav_Menu.findItem(R.id.sign123).setVisible(false);
        }


        binding.navigationView.setNavigationItemSelectedListener(item -> {


            int id = item.getItemId();

            if (id == R.id.setting) {
                Toast.makeText(MainActivity.this, "Setting", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.about_app) {
                Toast.makeText(MainActivity.this, "About app", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.privacy_policy) {
                Toast.makeText(MainActivity.this, "Privacy policy", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, PrivacyPoliciesActivity.class);
                startActivity(intent);
                finish();
            } else if (id == R.id.faq) {
                Toast.makeText(MainActivity.this, "FAQ", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.contact_us) {
                Toast.makeText(MainActivity.this, "Contact us", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto"," contact@gijutsusol.com", null));
                intent.putExtra(Intent.EXTRA_SUBJECT, subject);
                intent.putExtra(Intent.EXTRA_TEXT, message1);
                startActivity(Intent.createChooser(intent, "Choose an Email client :"));
                finish();
            } else if (id == R.id.sign123) {
                Toast.makeText(MainActivity.this, "Sign Up", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, SignUpPage.class);
                startActivity(intent);
                finish();

            } else if (id == R.id.sign456) {
                Toast.makeText(MainActivity.this, "Login", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, LoginPage.class);
                startActivity(intent);
                finish();
            } else if (id == R.id.logout) {


                showProgressDialog();
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(MainActivity.this, LoginPage.class);
                startActivity(intent);
                finish();
                hideProgressDialog();
                Toast.makeText(MainActivity.this, "Log out successfully", Toast.LENGTH_SHORT).show();

            } else {
                binding.drawerLayout.closeDrawer(GravityCompat.START);
            }

            return false;
        });

    }
    private void getCityDetails(String cityName) {

        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityName).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                String cityUrl = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("city").child("img").getValue()).substring(33, 66);


                Glide.with(MainActivity.this).load(cityUrl).into(binding.ivCityImg);


                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poa1 = poaList.get(0);
                poa2 = poaList.get(1);
                binding.etSearchBox.setHint(cityName);
                TextView poa1t = findViewById(R.id.textpoa1);
                TextView poa2t = findViewById(R.id.textpoa2);

                poa1t.setText(poa1);
                poa2t.setText(poa2);

                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);

                Glide.with(MainActivity.this).load(poaUrl1).into(binding.ivPoa1);

                Glide.with(MainActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        hideProgressDialog();
                        return false;
                    }
                }).into(binding.ivPoa2);
                String poaUrl3 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img2").getValue()).substring(33, 66);
                String poaUrl4 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img2").getValue()).substring(33, 66);

                Glide.with(MainActivity.this).load(poaUrl3).into(binding.ivPda1);

                Glide.with(MainActivity.this).load(poaUrl4).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        hideProgressDialog();
                        return false;
                    }
                }).into(binding.ivPda2);


            }
        });
    }


    private void getAllCityName() {
        showProgressDialog();
        FirebaseDatabase.getInstance(dbUrl).getReference().get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {
                cityList.clear();

                for (DataSnapshot i : dataSnapshot.getChildren()) {
                    cityList.add(i.getKey());
                }
                cityList.remove("Users");
                hideProgressDialog();
            }
        });


    }

    private void showProgressDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.progress_dialog, null);


        builder.setView(dialogLayout);

        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    private void hideProgressDialog() {
        alertDialog.dismiss();
    }


    private void getCityDetailsFromWiki(String city) {

        String[] nameArray = city.trim().split(" ");
        String url = "https://en.wikipedia.org/api/rest_v1/page/summary/" + nameArray[0];

        RequestQueue requestQueue;
        requestQueue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url, null,
                response -> {
                    try {
                        binding.tvCityDetails.setText(response.getString("extract"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }, error -> {
        });

        requestQueue.add(jsonObjectRequest);
    }

    private void loadDataForFirstTime() {

        if(message==null ){
            city = "Delhi";
            getCityDetails(city);
            getCityDetailsFromWiki(city);
        }
        else{
            city = String.valueOf(message.toString());
            getCityDetails(city);
            getCityDetailsFromWiki(city);

        }


    }

    private void getUserNameFromDB() {
        FirebaseDatabase database = FirebaseDatabase.getInstance(dbUrl);
        DatabaseReference usersRef = database.getReference("Users");

        usersRef.child(mAuth.getUid()).child("name").get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.getValue() != null) {
                binding.tvUserName.setText(dataSnapshot.getValue().toString());
            } else {
                binding.tvUserName.setText("Traveler");
            }
        });

    }

}