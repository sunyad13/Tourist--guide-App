package com.gijutsusol.indiaghumo;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.gijutsusol.indiaghumo.databinding.ActivityLoginBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginPage extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private FirebaseAuth mAuth;
    private AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();

        binding.tvForgotPassword.setOnClickListener(v -> {
            Intent intent1 = new Intent(LoginPage.this, RecoveryPasswordActivity.class);
            binding.etLogin.getText();
            intent1.putExtra("Login", binding.etLogin.getText().toString());
            startActivity(intent1);
        });

        binding.tvSignUp.setOnClickListener(v -> {
            Intent intent1 = new Intent(LoginPage.this, SignUpPage.class);
            binding.etLogin.getText();
            intent1.putExtra("Login", binding.etLogin.getText().toString());
            startActivity(intent1);
        });


        binding.LoginButton.setOnClickListener(v -> loginUserAccount());

        /**
        binding.tvFacebook.setOnClickListener(v -> {
        });
        binding.tvGoogle.setOnClickListener(v -> {
        });
        binding.tvInstagram.setOnClickListener(v -> {
        });
        binding.tvTwitter.setOnClickListener(v -> {
        }); **/
        binding.guest.setOnClickListener(v -> {
            Intent intent = new Intent(LoginPage.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }


    private void loginUserAccount() {

        showProgressDialog();

        String email, password;

        email = binding.etLogin.getText().toString();
        password = binding.etPassword.getText().toString();


        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getApplicationContext(), "Please enter email!!", Toast.LENGTH_LONG).show();
            hideProgressDialog();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getApplicationContext(), "Please enter password!!", Toast.LENGTH_LONG).show();
            hideProgressDialog();
            return;
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(
                        task -> {
                            if (task.isSuccessful()) {
                                hideProgressDialog();
                                checkIfEmailVerified();
                            } else {
                                Toast.makeText(getApplicationContext(), "Login failed!!", Toast.LENGTH_LONG).show();
                                hideProgressDialog();
                            }
                        });
    }

    private void checkIfEmailVerified() {
        FirebaseUser user = mAuth.getCurrentUser();

        if (user != null) {
            if (user.isEmailVerified()) {
                Intent intent = new Intent(LoginPage.this, MainActivity.class);
                startActivity(intent);
                finish();
                Toast.makeText(LoginPage.this, "Successfully verified and logged in", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "You did not verify yet!!", Toast.LENGTH_LONG).show();

                Intent intent = new Intent(LoginPage.this, MainActivity.class);
                startActivity(intent);
                finish();

                //mAuth.signOut();

            }
        }
    }

    private void showProgressDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.progress_dialog, null);


        builder.setView(dialogLayout);

        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    private void hideProgressDialog() {
        alertDialog.dismiss();
    }
}