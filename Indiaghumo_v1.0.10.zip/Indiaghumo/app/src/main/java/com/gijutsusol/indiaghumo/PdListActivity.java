package com.gijutsusol.indiaghumo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.gijutsusol.indiaghumo.databinding.ActivityMainBinding;
import com.gijutsusol.indiaghumo.databinding.ActivityPdListBinding;
import com.gijutsusol.indiaghumo.databinding.ActivityPoaListBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class PdListActivity extends AppCompatActivity {
    private ActivityPdListBinding binding;
    private ArrayList<String> cities = new ArrayList<>();
    private ArrayList<String> texts = new ArrayList<>();
    private ArrayList<String> poass = new ArrayList<>();
    private AlertDialog alertDialog;
    TextView txtView6;
    private String city;
    private String poa1;
    private String poa2;
    private String poa3;
    private String poa4;
    private String poa5;
    private String poa6;
    private String poa7;
    private String poa8;
    private String poa9;
    private String poa10;
    private String poa11;
    private String poa12;
    private String poa13;
    private String poa14;
    private String poa15;
    private String poa16;
    private String poa17,poa18;

    private final String dbUrl = "https://indiaghumo-4dfda-default-rtdb.asia-southeast1.firebasedatabase.app/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPdListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        txtView6 = findViewById(R.id.textView6);
        txtView6.setText(GlobalVariable.message);
        TextView loc = findViewById(R.id.textView6);
        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PdListActivity.this,LocationActivity.class);
                startActivity(i);
            }
        });
        city = (String) getIntent().getExtras().get("CITY_NAME");
        getCityDetails(city);
        for(int i=0; i<18;i++){
            poass.add("");
        }
        if(!city.equals("Ghaziabad")){ cities.add("Ghaziabad");};
        if(!city.equals("Guwahati")){ cities.add("Guwahati");};
        if(!city.equals("Udaipur")){cities.add("Udaipur");};
        if(!city.equals("Ahmedabad")){cities.add("Ahmedabad");};
        if(!city.equals("Delhi")){cities.add("Delhi");};
        if(!city.equals("Mumbai")){ cities.add("Mumbai");};
        if(!city.equals("Dehradun")){cities.add("Dehradun");};
        if(!city.equals("Bangalore")){cities.add("Bangalore");};
        if(!city.equals("Varanasi")){cities.add("Varanasi");};
        int cnt = 3;
        for(int i=0;i<8;i++){
            if(cnt==3){
                poassdef3(cities.get(i),cnt);
            }
            if(cnt==5){
                poassdef5(cities.get(i),cnt);
            }
            if(cnt==7){
                poassdef7(cities.get(i),cnt);
            }
            if(cnt==9){
                poassdef9(cities.get(i),cnt);
            }
            if(cnt==11){
                poassdef11(cities.get(i),cnt);
            }
            if(cnt==13){
                poassdef13(cities.get(i),cnt);
            }if(cnt==15){
                poassdef15(cities.get(i),cnt);
            }if(cnt==17){
                poassdef17(cities.get(i),cnt);
            }
            cnt+=2;

        }
        binding.ivPda1.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", city);
            intent.putExtra("POA_NAME", poa1);

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());

        });
        binding.ivPda2.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", city);
            intent.putExtra("POA_NAME", poa2);

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());

        });
        binding.ivPda3.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(0));
            intent.putExtra("POA_NAME", poass.get(2));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda4.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(0));
            intent.putExtra("POA_NAME", poass.get(3));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda5.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(1));
            intent.putExtra("POA_NAME", poass.get(4));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda6.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(1));
            intent.putExtra("POA_NAME", poass.get(5));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda7.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(2));
            intent.putExtra("POA_NAME", poass.get(6));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda8.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(2));
            intent.putExtra("POA_NAME", poass.get(7));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda9.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(3));
            intent.putExtra("POA_NAME", poass.get(8));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda10.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(3));
            intent.putExtra("POA_NAME", poass.get(9));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda11.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(4));
            intent.putExtra("POA_NAME", poass.get(10));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda12.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(4));
            intent.putExtra("POA_NAME", poass.get(11));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda13.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(5));
            intent.putExtra("POA_NAME", poass.get(12));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda14.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(5));
            intent.putExtra("POA_NAME", poass.get(13));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda15.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(6));
            intent.putExtra("POA_NAME", poass.get(14));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda16.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(6));
            intent.putExtra("POA_NAME", poass.get(15));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda17.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(7));
            intent.putExtra("POA_NAME", poass.get(16));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPda18.setOnClickListener(view -> {
            Intent intent = new Intent(PdListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(7));
            intent.putExtra("POA_NAME", poass.get(17));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPda1, 100, 100, 100, 100).toBundle());
        });


    }

    private void getCityDetails(String cityName) {

        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityName).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poa1 = poaList.get(0);
                poa2 = poaList.get(1);
                poass.set(0,poa1);
                poass.set(1,poa2);
                binding.pda1.setText(poa1);
                binding.pda2.setText(poa2);

                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PdListActivity.this).load(poaUrl1).into(binding.ivPda1);

                Glide.with(PdListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPda2);


            }
        });
    }
    private void showProgressDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.progress_dialog, null);


        builder.setView(dialogLayout);

        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    private void hideProgressDialog() {
        alertDialog.dismiss();
    }

    private void poassdef3(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.pda3.setText(poass.get(cnt-1));
                binding.pda4.setText(poass.get(cnt));

                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PdListActivity.this).load(poaUrl1).into(binding.ivPda3);

                Glide.with(PdListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPda4);


            }
        });

    }
    private void poassdef5(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.pda5.setText(poass.get(cnt-1));
                binding.pda6.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PdListActivity.this).load(poaUrl1).into(binding.ivPda5);

                Glide.with(PdListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPda6);


            }
        });

    }
    private void poassdef7(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.pda7.setText(poass.get(cnt-1));
                binding.pda8.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PdListActivity.this).load(poaUrl1).into(binding.ivPda7);

                Glide.with(PdListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPda8);


            }
        });

    }
    private void poassdef9(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.pda9.setText(poass.get(cnt-1));
                binding.pda10.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PdListActivity.this).load(poaUrl1).into(binding.ivPda9);
                Glide.with(PdListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPda10);


            }
        });

    }
    private void poassdef11(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.pda11.setText(poass.get(cnt-1));
                binding.pda12.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PdListActivity.this).load(poaUrl1).into(binding.ivPda11);

                Glide.with(PdListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPda12);


            }
        });

    }
    private void poassdef13(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.pda13.setText(poass.get(cnt-1));
                binding.pda14.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PdListActivity.this).load(poaUrl1).into(binding.ivPda13);

                Glide.with(PdListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPda14);


            }
        });

    }
    private void poassdef15(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.pda15.setText(poass.get(cnt-1));
                binding.pda16.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PdListActivity.this).load(poaUrl1).into(binding.ivPda15);

                Glide.with(PdListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPda16);


            }
        });

    }
    private void poassdef17(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.pda17.setText(poass.get(cnt-1));
                binding.pda18.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PdListActivity.this).load(poaUrl1).into(binding.ivPda17);

                Glide.with(PdListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPda18);


            }
        });

    }
}