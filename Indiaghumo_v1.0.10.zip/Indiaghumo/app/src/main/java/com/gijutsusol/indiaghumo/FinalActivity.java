package com.gijutsusol.indiaghumo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;
import java.util.ArrayList;

public class FinalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);
        ArrayList<String> details = (ArrayList<String>) getIntent().getExtras().get("DETAILS");
        StringBuffer buffer = new StringBuffer();
        for(int i=0;i<details.size();i++){
            if(details.get(i).length()!=0){
                buffer.append(details.get(i)+"\n");
            }
        }
        Button modify = (Button) findViewById(R.id.modify);
        modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FinalActivity.this,BookingActivity.class);
                startActivity(intent);
            }
        });
        Button email = (Button) findViewById(R.id.email);
        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent email = new Intent(Intent.ACTION_SEND);
                email.putExtra(Intent.EXTRA_EMAIL, new String[]{"contact@gijutsusol.com"});
                email.putExtra(Intent.EXTRA_SUBJECT, details.get(0)+" Booking");
                email.putExtra(Intent.EXTRA_TEXT, (Serializable) buffer);
                email.setType("message/rfc822");

                startActivity(Intent.createChooser(email, "Choose an Email client :"));
            }
        });
    }
}