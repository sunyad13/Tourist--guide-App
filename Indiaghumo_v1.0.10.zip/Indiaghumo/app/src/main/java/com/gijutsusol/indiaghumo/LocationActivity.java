package com.gijutsusol.indiaghumo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.TextView;

import com.gijutsusol.indiaghumo.databinding.ActivityLocationBinding;
import com.gijutsusol.indiaghumo.databinding.ActivityMainBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LocationActivity extends AppCompatActivity {

    Button btnLocation, btnNo, buttonSet;
    TextView txtView1, txtView2, txtView3, txtView4, txtView5, searchView;
    FusedLocationProviderClient fusedLocationProviderClient;
    private ActivityLocationBinding binding;
    private final ArrayList<String> cityList = new ArrayList<>();
    private AlertDialog alertDialog;
    private String city;
    private String poa1;
    private String poa2;
    private final String dbUrl = "https://indiaghumo-4dfda-default-rtdb.asia-southeast1.firebasedatabase.app/";
    private FirebaseUser mAuth;
    TextView txtView6;
    String location;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLocationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        btnLocation = findViewById(R.id.buttonLocation);
        btnNo = findViewById(R.id.buttonNo);
        buttonSet = findViewById(R.id.btnSetLocation);
        txtView2 = findViewById(R.id.textView2);
        txtView3 = findViewById(R.id.textView3);
        txtView4 = findViewById(R.id.textView4);
        searchView = findViewById(R.id.et_search_box);

        getAllCityName();
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, cityList);
        binding.etSearchBox.setAdapter(cityAdapter);

        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LocationActivity.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });
        buttonSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GlobalVariable.message = searchView.getText().toString();
                GlobalVariable.message2 = txtView2.getText().toString();
                Intent intent = new Intent(LocationActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        {


        }

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        btnLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(LocationActivity.this,
                        Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    getLocation();
                } else {
                    ActivityCompat.requestPermissions(LocationActivity.this,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 44);
                }
            }
        });
    }

    private void getAllCityName() {

        FirebaseDatabase.getInstance(dbUrl).getReference().get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {
                cityList.clear();

                for (DataSnapshot i : dataSnapshot.getChildren()) {
                    cityList.add(i.getKey());
                }
                cityList.remove("Users");
            }
        });
    }


    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        fusedLocationProviderClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
            @Override
            public void onComplete(@NonNull Task<Location> task) {
                Location location = task.getResult();
                if (location != null) {

                    try {
                        Geocoder geocoder = new Geocoder(LocationActivity.this, Locale.getDefault());
                        List<Address> addresses = geocoder.getFromLocation(
                                location.getLatitude(), location.getLongitude(), 1
                        );
                        txtView2.setText(Html.fromHtml(
                                "<font color='#FF000000'><b>City:</b><br></font>"
                                        + addresses.get(0).getLocality()
                        ));


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
    }

}