package com.gijutsusol.indiaghumo;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.gijutsusol.indiaghumo.databinding.ActivityForgotPasswordBinding;
import com.google.firebase.auth.FirebaseAuth;

public class RecoveryPasswordActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    private ActivityForgotPasswordBinding binding;
    private AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityForgotPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();

        binding.RecoveryUpButton.setOnClickListener(v ->
                RecoveryPassword(binding.etLogin.getText().toString())
        );

    }

    private void RecoveryPassword(String email) {
        showProgressDialog();

        mAuth.sendPasswordResetEmail(email).addOnSuccessListener(unused -> {
            hideProgressDialog();
            Intent intent = new Intent(RecoveryPasswordActivity.this, LoginPage.class);
            startActivity(intent);
            Toast.makeText(this, "Password recovery mail is sent, please check email", Toast.LENGTH_LONG).show();

        }).addOnFailureListener(e -> {
            hideProgressDialog();
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show();
        });
    }

    private void showProgressDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.progress_dialog, null);


        builder.setView(dialogLayout);

        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    private void hideProgressDialog() {
        alertDialog.dismiss();
    }
}