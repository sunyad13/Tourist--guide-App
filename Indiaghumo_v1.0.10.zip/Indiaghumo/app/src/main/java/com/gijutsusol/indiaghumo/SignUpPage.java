package com.gijutsusol.indiaghumo;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.gijutsusol.indiaghumo.databinding.ActivitySignupBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUpPage extends AppCompatActivity {

    private ActivitySignupBinding binding;
    private FirebaseAuth mAuth;
    private AlertDialog alertDialog;
    private DatabaseReference usersRef;
    private final String dbUrl = "https://indiaghumo-4dfda-default-rtdb.asia-southeast1.firebasedatabase.app/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        FirebaseDatabase database = FirebaseDatabase.getInstance(dbUrl);
        usersRef = database.getReference("Users");


        binding.SignUpButton.setOnClickListener(v -> registerNewUser());

    }

    private void registerNewUser() {

        showProgressDialog();


        String email, password, name, passwordConfirm;

        email = binding.etlogin.getText().toString();
        password = binding.etPassword.getText().toString();
        passwordConfirm = binding.etPasswordConfirm.getText().toString();
        name = binding.etName.getText().toString();

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getApplicationContext(),
                            "Please enter email!!",
                            Toast.LENGTH_LONG)
                    .show();
            hideProgressDialog();
            return;
        }
        if (TextUtils.isEmpty(name)) {
            Toast.makeText(getApplicationContext(),
                            "Please enter name!!",
                            Toast.LENGTH_LONG)
                    .show();
            hideProgressDialog();
            return;
        }
        if (TextUtils.isEmpty(passwordConfirm)) {
            Toast.makeText(getApplicationContext(),
                            "Please enter Confirm password!!",
                            Toast.LENGTH_LONG)
                    .show();
            hideProgressDialog();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getApplicationContext(),
                            "Please enter password!!",
                            Toast.LENGTH_LONG)
                    .show();
            hideProgressDialog();
            return;
        }
        if (!password.equals(passwordConfirm)) {
            Toast.makeText(getApplicationContext(),
                            "Passwords are different!!",
                            Toast.LENGTH_LONG)
                    .show();
            hideProgressDialog();
            return;
        }


        mAuth.createUserWithEmailAndPassword(email.trim(), password.trim())
                .addOnSuccessListener(authResult -> {

                    hideProgressDialog();
                    sendVerificationEmail(name, email);

                }).addOnFailureListener(e -> {
                    Toast.makeText(getApplicationContext(), "Registration failed!!" + e.getMessage(), Toast.LENGTH_LONG).show();

                    hideProgressDialog();
                });


    }

    private void sendVerificationEmail(String name, String email) {

        showProgressDialog();

        FirebaseUser user = mAuth.getCurrentUser();

        if (user != null) {

            user.sendEmailVerification()
                    .addOnSuccessListener(unused -> {

                        Users users = new Users(name, email);
                        usersRef.child(user.getUid()).setValue(users);

                        mAuth.signOut();
                        startActivity(new Intent(SignUpPage.this, LoginPage.class));
                        finish();

                        hideProgressDialog();

                        Toast.makeText(this, "Verification link sent", Toast.LENGTH_LONG).show();

                    }).addOnFailureListener(e -> {
                        Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show();
                        hideProgressDialog();
                    });
        }


    }

    private void showProgressDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.progress_dialog, null);


        builder.setView(dialogLayout);

        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    private void hideProgressDialog() {
        alertDialog.dismiss();
    }

}