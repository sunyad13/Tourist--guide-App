package com.gijutsusol.indiaghumo;

public class Location {
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    private double latitude;

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    private double longitude;
    private String city;


    public Location(String city, double latitude, double longitude) {
        this.latitude = latitude;
        this.city = city;
        this.longitude = longitude;
    }


}
