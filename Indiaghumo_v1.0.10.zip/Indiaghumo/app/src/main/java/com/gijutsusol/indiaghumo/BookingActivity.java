package com.gijutsusol.indiaghumo;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.gijutsusol.indiaghumo.databinding.ActivityBookingBinding;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class BookingActivity extends AppCompatActivity {
    private ActivityBookingBinding binding;
    final Calendar myCalendar= Calendar.getInstance();
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBookingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabel1();
            }
        };
        DatePickerDialog.OnDateSetListener ret = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabel2();
            }
        };
        binding.bookdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(BookingActivity.this,date,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        binding.returndate.setOnClickListener(view -> {
            new DatePickerDialog(BookingActivity.this,ret,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();

        });
        binding.flightbutton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(binding.flightbutton.isChecked()){
                    binding.trainbutton.setChecked(false);
                    binding.linearLayout2.setVisibility(View.VISIBLE);

                }
            }
        });
        binding.trainbutton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(binding.trainbutton.isChecked()){
                    binding.flightbutton.setChecked(false);
                    binding.linearLayout2.setVisibility(View.VISIBLE);

                }
            }
        });
        binding.oneway.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(binding.oneway.isChecked()){
                    binding.roundtrip.setChecked(false);
                    binding.finalbooking.setVisibility(View.VISIBLE);
                    binding.returndate.setVisibility(View.GONE);
                }
            }
        });
        binding.roundtrip.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(binding.roundtrip.isChecked()){
                    binding.oneway.setChecked(false);
                    binding.finalbooking.setVisibility(View.VISIBLE);
                    binding.returndate.setVisibility(View.VISIBLE);
                }
            }
        });
        binding.submit.setOnClickListener(view -> {
            ArrayList<String> details = new ArrayList<String>();
            for(int i=0;i<7;i++){
                details.add("");
            }
            if(binding.flightbutton.isChecked()){
                details.set(0,"FLIGHT");
                if(binding.oneway.isChecked()){
                    details.set(1,"One-Way");
                    details.set(2,"FROM:-" + binding.from.getText().toString());
                    details.set(3,"TO:- " +binding.to.getText().toString());
                    details.set(4,"BOOKDATE:- "+ binding.bookdate.getText().toString());
                    details.set(6,"ADULTS:- " + binding.adults.getText().toString());


                }else if(binding.roundtrip.isChecked()){
                    details.set(1,"Round-Way");
                    details.set(2,"FROM:-" + binding.from.getText().toString());
                    details.set(3,"TO:- " +binding.to.getText().toString());
                    details.set(5,"RETURN DATE:- " + binding.returndate.getText().toString());
                    details.set(4,"BOOKDATE:- "+ binding.bookdate.getText().toString());
                    details.set(6,"ADULTS:- " + binding.adults.getText().toString());

                }
            }else if(binding.trainbutton.isChecked()) {
                details.set(0, "TRAIN");
                if (binding.oneway.isChecked()) {
                    details.set(1, "One-Way");
                    details.set(2,"FROM:-" + binding.from.getText().toString());
                    details.set(3,"TO:- " +binding.to.getText().toString());
                    details.set(4,"BOOKDATE:- "+ binding.bookdate.getText().toString());
                    details.set(6,"ADULTS:- " + binding.adults.getText().toString());

                } else if (binding.roundtrip.isChecked()) {
                    details.set(1, "Round-Way");
                    details.set(2,"FROM:-" + binding.from.getText().toString());
                    details.set(3,"TO:- " +binding.to.getText().toString());
                    details.set(5,"RETURN DATE:- " + binding.returndate.getText().toString());
                    details.set(4,"BOOKDATE:- "+ binding.bookdate.getText().toString());
                    details.set(6,"ADULTS:- " + binding.adults.getText().toString());

                }
            }

            Intent intent = new Intent(BookingActivity.this,FinalActivity.class);
            intent.putExtra("DETAILS",details);
            startActivity(intent);
        });
    }

    private void updateLabel1(){
        String myFormat="MM/dd/yy";
        editText = findViewById(R.id.bookdate);
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
        editText.setText("ON :- "+dateFormat.format(myCalendar.getTime()));
    }
    private void updateLabel2(){
        String myFormat="MM/dd/yy";
        editText = findViewById(R.id.returndate);
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
        editText.setText("RETURN :- "+dateFormat.format(myCalendar.getTime()));
    }
}