package com.gijutsusol.indiaghumo;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.gijutsusol.indiaghumo.databinding.ActivityCityBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONException;

public class CityActivity extends AppCompatActivity {

    private ActivityCityBinding binding;
    private AlertDialog alertDialog;
    TextView txtView6;
    private final String dbUrl = "https://indiaghumo-4dfda-default-rtdb.asia-southeast1.firebasedatabase.app/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        txtView6 = findViewById(R.id.textView6);
        txtView6.setText(GlobalVariable.message);

        TextView loc = findViewById(R.id.textView6);
        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CityActivity.this,LocationActivity.class);
                startActivity(i);
            }
        });
        String city = (String) getIntent().getExtras().get("CITY_NAME");

        binding.tvCityName.setText(city);

        getDetails(city);

        getCityDetails(city);

        binding.btnMap.setOnClickListener(v -> {
            String location = "http://maps.google.co.in/maps?q=" + city.trim();
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(location));
            startActivity(intent);
        });

        ImageView navBtn = findViewById(R.id.cab_menu);

        navBtn.setOnClickListener(v -> {
            binding.drawerLayout.openDrawer(GravityCompat.START);
        });

        binding.navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.setting) {
                Toast.makeText(CityActivity.this, "Setting", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.about_app) {
                Toast.makeText(CityActivity.this, "About app", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.privacy_policy) {
                Toast.makeText(CityActivity.this, "Privacy policy", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.faq) {
                Toast.makeText(CityActivity.this, "FAQ", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.contact_us) {
                Toast.makeText(CityActivity.this, "Contact us", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.logout) {
                showProgressDialog();
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(CityActivity.this, LoginPage.class);
                startActivity(intent);
                finish();
                hideProgressDialog();
                Toast.makeText(CityActivity.this, "Log out successfully", Toast.LENGTH_SHORT).show();
            } else {
                binding.drawerLayout.closeDrawer(GravityCompat.START);
            }

            return false;
        });

    }

    private void showProgressDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.progress_dialog, null);

        builder.setView(dialogLayout);

        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    private void hideProgressDialog() {
        alertDialog.dismiss();
    }


    private void getDetails(String cityName) {

        showProgressDialog();

        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityName).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                String url = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("city").child("img").getValue()).substring(33, 66);

                Glide.with(CityActivity.this).load(url).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        binding.progressBar.setVisibility(View.GONE);
                        return false;
                    }
                }).into(binding.ivCityImg);

                hideProgressDialog();
            }
        });
    }

    private void getCityDetails(String city) {

        String[] nameArray = city.trim().split(" ");

        String url = "https://en.wikipedia.org/api/rest_v1/page/summary/" + nameArray[0];

        RequestQueue requestQueue;
        requestQueue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url, null,
                response -> {
                    try {
                        binding.tvCityDetails.setText(response.getString("extract"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(CityActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }, error -> {

        });

        requestQueue.add(jsonObjectRequest);
    }
}