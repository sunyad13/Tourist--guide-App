package com.gijutsusol.indiaghumo;

public class GlobalVariable  {
    public static String message,subject,message1,Location,city,message2;
}
