package com.gijutsusol.indiaghumo;

import static com.gijutsusol.indiaghumo.GlobalVariable.message;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class RpListActivity extends AppCompatActivity {
    TextView txtView6;
    String location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rp_list);
        txtView6 = findViewById(R.id.textView6);
        txtView6.setText(message);
        TextView loc = findViewById(R.id.textView6);
        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(RpListActivity.this,LocationActivity.class);
                startActivity(i);
            }
        });

    }
}