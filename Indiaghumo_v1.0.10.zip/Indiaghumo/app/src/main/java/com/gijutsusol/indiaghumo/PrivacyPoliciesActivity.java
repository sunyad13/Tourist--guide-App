package com.gijutsusol.indiaghumo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

public class PrivacyPoliciesActivity extends AppCompatActivity {

    TextView linkText1;
    TextView linkText2;

    @Override
    public void onBackPressed() {
        Intent i = new Intent(PrivacyPoliciesActivity.this,MainActivity.class);
        startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_policies);

        linkText1 = findViewById(R.id.parent_matrix);
        linkText1.setMovementMethod(LinkMovementMethod.getInstance());

    }
}