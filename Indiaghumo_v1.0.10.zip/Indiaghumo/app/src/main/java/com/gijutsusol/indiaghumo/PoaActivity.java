package com.gijutsusol.indiaghumo;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.gijutsusol.indiaghumo.databinding.ActivityPoaBinding;

import java.util.ArrayList;

public class PoaActivity extends AppCompatActivity {

    private AlertDialog alertDialog;
    private ActivityPoaBinding binding;
    TextView txtView6;

    private final String dbUrl = "https://indiaghumo-4dfda-default-rtdb.asia-southeast1.firebasedatabase.app/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPoaBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        txtView6 = findViewById(R.id.textView6);
        txtView6.setText(GlobalVariable.message);

        String city = (String) getIntent().getExtras().get("CITY_NAME");
        String poa = (String) getIntent().getExtras().get("POA_NAME");

        binding.tvPoaName.setText(poa);
        getDetails(city, poa);
        TextView loc = findViewById(R.id.textView6);
        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PoaActivity.this,LocationActivity.class);
                startActivity(i);
            }
        });
        binding.btnMap.setOnClickListener(v -> {
            String location = "http://maps.google.co.in/maps?q=" + poa.trim() + " " + city;
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(location));
            startActivity(intent);
        });
        binding.book.setOnClickListener(view -> {
            Intent intent = new Intent(PoaActivity.this,BookingActivity.class);
            startActivity(intent);
        });


        ImageView navBtn = findViewById(R.id.cab_menu);

        navBtn.setOnClickListener(v -> {
            binding.drawerLayout.openDrawer(GravityCompat.START);
        });

        binding.navigationView.setNavigationItemSelectedListener(item -> {

            int id = item.getItemId();
            if (id == R.id.setting) {
                Toast.makeText(PoaActivity.this, "Setting", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.about_app) {
                Toast.makeText(PoaActivity.this, "About app", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.privacy_policy) {
                Toast.makeText(PoaActivity.this, "Privacy policy", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.faq) {
                Toast.makeText(PoaActivity.this, "FAQ", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.contact_us) {
                Toast.makeText(PoaActivity.this, "Contact us", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.sign123) {
                    Toast.makeText(PoaActivity.this, "Sign Up", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(PoaActivity.this, SignUpPage.class);
                startActivity(intent);
                finish();
            } else if (id == R.id.logout) {
                showProgressDialog();
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(PoaActivity.this, LoginPage.class);
                startActivity(intent);
                finish();
                hideProgressDialog();
                Toast.makeText(PoaActivity.this, "Log out successfully", Toast.LENGTH_SHORT).show();
            } else {
                binding.drawerLayout.closeDrawer(GravityCompat.START);
            }

            return false;
        });

    }

    private void showProgressDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.progress_dialog, null);


        builder.setView(dialogLayout);

        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    private void hideProgressDialog() {
        alertDialog.dismiss();
    }


    private void getDetails(String cityName, String poaName) {

        showProgressDialog();

        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityName).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {
                ArrayList<String>  about = new ArrayList<>();
                ArrayList<String> urlList = new ArrayList<>();
                int cnt = 0;
                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaName)).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaName)).child("img2").getValue()).substring(33, 66);
                String des = String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaName)).child("des").getValue());
                String wtv = String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaName)).child("wtv").getValue());
                urlList.add(poaUrl1);
                urlList.add(poaUrl2);
                about.add(des);
                about.add(wtv);

                description(about);
                ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(this, urlList);
                binding.viewPager.setAdapter(viewPagerAdapter);
                binding.dotsIndicator.attachTo(binding.viewPager);

                hideProgressDialog();
            }
        });
    }
    private void description(ArrayList<String> about){
        TextView textView = findViewById(R.id.des);
        textView.setText(about.get(0));
        TextView wtv = findViewById(R.id.wtv);
        wtv.setText(about.get(1));

    }
}