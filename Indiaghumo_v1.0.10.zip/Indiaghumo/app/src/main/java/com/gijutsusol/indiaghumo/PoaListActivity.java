package com.gijutsusol.indiaghumo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.gijutsusol.indiaghumo.databinding.ActivityMainBinding;
import com.gijutsusol.indiaghumo.databinding.ActivityPoaListBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class PoaListActivity extends AppCompatActivity {
    private ActivityPoaListBinding binding;
    private ArrayList<String> cities = new ArrayList<>();
    private ArrayList<String> texts = new ArrayList<>();
    private ArrayList<String> poass = new ArrayList<>();
    private AlertDialog alertDialog;
    TextView txtView6;
    private String city;
    private String poa1;
    private String poa2;
    private String poa3;
    private String poa4;
    private String poa5;
    private String poa6;
    private String poa7;
    private String poa8;
    private String poa9;
    private String poa10;
    private String poa11;
    private String poa12;
    private String poa13;
    private String poa14;
    private String poa15;
    private String poa16;
    private String poa17,poa18;

    private final String dbUrl = "https://indiaghumo-4dfda-default-rtdb.asia-southeast1.firebasedatabase.app/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPoaListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        txtView6 = findViewById(R.id.textView6);
        txtView6.setText(GlobalVariable.message);
        TextView loc = findViewById(R.id.textView6);
        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PoaListActivity.this,LocationActivity.class);
                startActivity(i);
            }
        });
        city = (String) getIntent().getExtras().get("CITY_NAME");
        getCityDetails(city);
        for(int i=0; i<18;i++){
            poass.add("");
        }
        if(!city.equals("Agra")){ cities.add("Agra");};
        if(!city.equals("Guwahati")){ cities.add("Guwahati");};
        if(!city.equals("Udaipur")){cities.add("Udaipur");};
        if(!city.equals("Ahmedabad")){cities.add("Ahmedabad");};
        if(!city.equals("Delhi")){cities.add("Delhi");};
        if(!city.equals("Mumbai")){ cities.add("Mumbai");};
        if(!city.equals("Chennai")){cities.add("Chennai");};
        if(!city.equals("Srinagar")){cities.add("Srinagar");};
        if(!city.equals("Varanasi")){cities.add("Varanasi");};
        int cnt = 3;
        for(int i=0;i<8;i++){
            if(cnt==3){
                poassdef3(cities.get(i),cnt);
            }
            if(cnt==5){
                poassdef5(cities.get(i),cnt);
            }
            if(cnt==7){
                poassdef7(cities.get(i),cnt);
            }
            if(cnt==9){
                poassdef9(cities.get(i),cnt);
            }
            if(cnt==11){
                poassdef11(cities.get(i),cnt);
            }
            if(cnt==13){
                poassdef13(cities.get(i),cnt);
            }if(cnt==15){
                poassdef15(cities.get(i),cnt);
            }if(cnt==17){
                poassdef17(cities.get(i),cnt);
            }
            cnt+=2;

        }
        binding.ivPoa1.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", city);
            intent.putExtra("POA_NAME", poa1);

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());

        });
        binding.ivPoa2.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", city);
            intent.putExtra("POA_NAME", poa2);

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());

        });
        binding.ivPoa3.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(0));
            intent.putExtra("POA_NAME", poass.get(2));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa4.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(0));
            intent.putExtra("POA_NAME", poass.get(3));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa5.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(1));
            intent.putExtra("POA_NAME", poass.get(4));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa6.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(1));
            intent.putExtra("POA_NAME", poass.get(5));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa7.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(2));
            intent.putExtra("POA_NAME", poass.get(6));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa8.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(2));
            intent.putExtra("POA_NAME", poass.get(7));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa9.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(3));
            intent.putExtra("POA_NAME", poass.get(8));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa10.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(3));
            intent.putExtra("POA_NAME", poass.get(9));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa11.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(4));
            intent.putExtra("POA_NAME", poass.get(10));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa12.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(4));
            intent.putExtra("POA_NAME", poass.get(11));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa13.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(5));
            intent.putExtra("POA_NAME", poass.get(12));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa14.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(5));
            intent.putExtra("POA_NAME", poass.get(13));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa15.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(6));
            intent.putExtra("POA_NAME", poass.get(14));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa16.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(6));
            intent.putExtra("POA_NAME", poass.get(15));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa17.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(7));
            intent.putExtra("POA_NAME", poass.get(16));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });
        binding.ivPoa18.setOnClickListener(view -> {
            Intent intent = new Intent(PoaListActivity.this, PoaActivity.class);
            intent.putExtra("CITY_NAME", cities.get(7));
            intent.putExtra("POA_NAME", poass.get(17));

            startActivity(intent, ActivityOptions.makeScaleUpAnimation(binding.ivPoa1, 100, 100, 100, 100).toBundle());
        });


    }

    private void getCityDetails(String cityName) {

        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityName).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poa1 = poaList.get(0);
                poa2 = poaList.get(1);
                poass.set(0,poa1);
                poass.set(1,poa2);
                binding.poa1.setText(poa1);
                binding.poa2.setText(poa2);

                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PoaListActivity.this).load(poaUrl1).into(binding.ivPoa1);

                Glide.with(PoaListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPoa2);


            }
        });
    }
    private void showProgressDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogLayout = inflater.inflate(R.layout.progress_dialog, null);


        builder.setView(dialogLayout);

        alertDialog = builder.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    private void hideProgressDialog() {
        alertDialog.dismiss();
    }

    private void poassdef3(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.poa3.setText(poass.get(cnt-1));
                binding.poa4.setText(poass.get(cnt));

                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PoaListActivity.this).load(poaUrl1).into(binding.ivPoa3);

                Glide.with(PoaListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPoa4);


            }
        });

    }
    private void poassdef5(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.poa5.setText(poass.get(cnt-1));
                binding.poa6.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PoaListActivity.this).load(poaUrl1).into(binding.ivPoa5);

                Glide.with(PoaListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPoa6);


            }
        });

    }
    private void poassdef7(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.poa7.setText(poass.get(cnt-1));
                binding.poa8.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PoaListActivity.this).load(poaUrl1).into(binding.ivPoa7);

                Glide.with(PoaListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPoa8);


            }
        });

    }
    private void poassdef9(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.poa9.setText(poass.get(cnt-1));
                binding.poa10.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PoaListActivity.this).load(poaUrl1).into(binding.ivPoa9);
                Glide.with(PoaListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPoa10);


            }
        });

    }
    private void poassdef11(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.poa11.setText(poass.get(cnt-1));
                binding.poa12.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PoaListActivity.this).load(poaUrl1).into(binding.ivPoa11);

                Glide.with(PoaListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPoa12);


            }
        });

    }
    private void poassdef13(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.poa13.setText(poass.get(cnt-1));
                binding.poa14.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PoaListActivity.this).load(poaUrl1).into(binding.ivPoa13);

                Glide.with(PoaListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPoa14);


            }
        });

    }
    private void poassdef15(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.poa15.setText(poass.get(cnt-1));
                binding.poa16.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PoaListActivity.this).load(poaUrl1).into(binding.ivPoa15);

                Glide.with(PoaListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPoa16);


            }
        });

    }
    private void poassdef17(String cityname,int cnt){
        FirebaseDatabase.getInstance(dbUrl).getReference().child(cityname).get().addOnSuccessListener(dataSnapshot -> {
            if (dataSnapshot.exists()) {

                ArrayList<String> poaList = new ArrayList<>();

                for (DataSnapshot i : dataSnapshot.child("poa").getChildren()) {
                    poaList.add(i.getKey());
                }

                poass.set(cnt-1,poaList.get(0));
                poass.set(cnt,poaList.get(1));
                binding.poa17.setText(poass.get(cnt-1));
                binding.poa18.setText(poass.get(cnt));


                String poaUrl1 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(0))).child("img1").getValue()).substring(33, 66);
                String poaUrl2 = "https://drive.google.com/uc?id=" + String.valueOf(dataSnapshot.child("poa").child(String.valueOf(poaList.get(1))).child("img1").getValue()).substring(33, 66);
                Glide.with(PoaListActivity.this).load(poaUrl1).into(binding.ivPoa17);

                Glide.with(PoaListActivity.this).load(poaUrl2).listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                }).into(binding.ivPoa18);


            }
        });

    }
}